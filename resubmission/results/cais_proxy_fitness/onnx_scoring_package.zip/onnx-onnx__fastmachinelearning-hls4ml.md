# CAIS Proxy-Fitness Evidence Packet

- Anchor: `onnx-onnx`
- Candidate: `fastmachinelearning/hls4ml`
- Repository URL: https://github.com/fastmachinelearning/hls4ml

## Repository metadata

Description: Machine learning on FPGAs using HLS

Topics: hls, machine-learning, fpga, python, keras, pytorch, onnx, vivado, vivado-hls, neural-network, intel-hls

## Frozen rubric

### ONX01 — Model serialization and interchange

Critical: True

Supports a portable model representation or conversion/interchange between model-producing and model-consuming systems.

Score: 

Evidence source: 

Evidence note: 

### ONX02 — Operator and schema compatibility

Critical: True

Supports explicit operators, schemas, graph structures, or compatibility rules governing model execution.

Score: 

Evidence source: 

Evidence note: 

### ONX03 — Model validation or checking

Critical: False

Supports validation of model structure, graph integrity, schema compliance, or equivalent correctness checks.

Score: 

Evidence source: 

Evidence note: 

### ONX04 — Shape and type inference

Critical: False

Supports propagation or validation of tensor shapes, types, dimensions, or equivalent interface contracts.

Score: 

Evidence source: 

Evidence note: 

### ONX05 — Runtime or backend interoperability

Critical: False

Supports execution or compatibility across multiple runtimes, frameworks, hardware targets, or backends.

Score: 

Evidence source: 

Evidence note: 

### ONX06 — Version and compatibility evolution

Critical: False

Supports model-format, operator-set, schema, or version compatibility testing across releases.

Score: 

Evidence source: 

Evidence note: 

## Retrieved README

<p align="center">
   <img src="https://raw.githubusercontent.com/fastmachinelearning/hls4ml/refs/heads/main/docs/img/hls4ml_logo.svg" alt="hls4ml" width="400"/>
</p>

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.19134628.svg)](https://doi.org/10.5281/zenodo.19134628)
[![License](https://img.shields.io/badge/License-Apache_2.0-red.svg)](https://opensource.org/licenses/Apache-2.0)
[![Documentation Status](https://github.com/fastmachinelearning/hls4ml/actions/workflows/sphinx.yml/badge.svg)](https://fastmachinelearning.org/hls4ml)
[![PyPI version](https://badge.fury.io/py/hls4ml.svg)](https://badge.fury.io/py/hls4ml)
[![Downloads](https://static.pepy.tech/personalized-badge/hls4ml?period=total&units=international_system&left_color=grey&right_color=orange&left_text=Downloads)](https://pepy.tech/project/hls4ml)
<a href="https://anaconda.org/conda-forge/hls4ml/"><img alt="conda-forge" src="https://img.shields.io/conda/dn/conda-forge/hls4ml.svg?label=conda-forge"></a>

A package for machine learning inference in FPGAs. We create firmware implementations of machine learning algorithms using high level synthesis language (HLS). We translate traditional open-source machine learning package models into HLS that can be configured for your use-case!

hls4ml is designed for ultra-low-latency inference on FPGAs. While it has strong roots in high-energy physics applications (e.g., L1 trigger systems at the CERN Large Hadron Collider), it has also been adopted across diverse scientific and industrial domains. Example use cases include control systems for quantum computing, feedback loops in nuclear fusion, low-power environmental monitoring on satellites, and biomedical signal processing (e.g., arrhythmia classification).


If you have any questions, comments, or ideas regarding hls4ml or just want to show us how you use hls4ml, don't hesitate to reach out to us through the [discussions](https://github.com/fastmachinelearning/hls4ml/discussions) tab.

# Documentation & Tutorial

For more information visit the webpage: [https://fastmachinelearning.org/hls4ml/](https://fastmachinelearning.org/hls4ml/).

For introductory material on FPGAs, HLS and ML inferences using hls4ml, check out the [video](https://www.youtube.com/watch?v=2y3GNY4tf7A&ab_channel=SystemsGroupatETHZ%C3%BCrich).

Detailed tutorials on how to use `hls4ml`'s various functionalities can be found [here](https://github.com/hls-fpga-machine-learning/hls4ml-tutorial).

# Installation
```bash
pip install hls4ml
```

To install the extra dependencies for profiling:

```bash
pip install hls4ml[profiling]
```

# Getting Started
### Creating an HLS project
```Python
import hls4ml

# Fetch a keras model from our example repository
# This will download our example model to your working directory and return an example configuration file
config = hls4ml.utils.fetch_example_model('KERAS_3layer.json')

# You can print the configuration to see some default parameters
print(config)

# Convert it to a hls project
hls_model = hls4ml.converters.keras_v2_to_hls(config)

# Print full list of example models if you want to explore more
hls4ml.utils.fetch_example_list()
```

### Building a project
We will build the project using Xilinx Vivado HLS, which can be downloaded and installed from [here](https://www.xilinx.com/products/design-tools/vivado/integration/esl-design.html). Alongside Vivado HLS, hls4ml also supports Vitis HLS, Intel HLS, Catapult HLS and has some experimental support for Intel oneAPI. The target backend can be changed using the argument backend when building the model.

```Python
# Use Vivado HLS to synthesize the model
# This might take several minutes
hls_model.build()

# Print out the report if you want
hls4ml.report.read_vivado_report('my-hls-test')
```

# FAQ

The list of frequently asked questions and common HLS synthesis issues can be found [here](https://fastmachinelearning.org/hls4ml/intro/faq.html).

# Citation
If you use this software in a publication, please cite the software
```bibtex
@software{fastml_hls4ml,
  author       = {{FastML Team}},
  title        = {fastmachinelearning/hls4ml},
  year         = 2026,
  publisher    = {Zenodo},
  version      = {v1.3.0},
  doi          = {10.5281/zenodo.1201549},
  url          = {https://github.com/fastmachinelearning/hls4ml}
}
```
the first publication:
```bibtex
@article{Duarte:2018ite,
    author = "Duarte, Javier and others",
    title = "{Fast inference of deep neural networks in FPGAs for particle physics}",
    eprint = "1804.06913",
    archivePrefix = "arXiv",
    primaryClass = "physics.ins-det",
    reportNumber = "FERMILAB-PUB-18-089-E",
    doi = "10.1088/1748-0221/13/07/P07027",
    journal = "JINST",
    volume = "13",
    number = "07",
    pages = "P07027",
    year = "2018"
}
```
and the latest overview paper:
```bibtex
@article{Schulte:2025mai,
    author = "Schulte, Jan-Frederik and others",
    title = "{hls4ml: A Flexible, Open-Source Platform for Deep Learning Acceleration on Reconfigurable Hardware}",
    eprint = "2512.01463",
    archivePrefix = "arXiv",
    primaryClass = "cs.AR",
    reportNumber = "FERMILAB-PUB-25-0890-CSAID-ETD-PPD",
    year = "2026",
    doi = "10.1145/3801979",
    journal = "ACM Trans. Reconfigurable Technol. Syst."
    volume = "19",
    pages = "19",
}


```

Additionally, if you use specific features developed in later papers, please cite those as well. For example, CNNs:
```bibtex
@article{Aarrestad:2021zos,
    author = "Aarrestad, Thea and others",
    title = "{Fast convolutional neural networks on FPGAs with hls4ml}",
    eprint = "2101.05108",
    archivePrefix = "arXiv",
    primaryClass = "cs.LG",
    reportNumber = "FERMILAB-PUB-21-130-SCD",
    doi = "10.1088/2632-2153/ac0ea1",
    journal = "Mach. Learn. Sci. Tech.",
    volume = "2",
    number = "4",
    pages = "045015",
    year = "2021"
}
@article{Ghielmetti:2022ndm,
    author = "Ghielmetti, Nicol\`{o} and others",
    title = "{Real-time semantic segmentation on FPGAs for autonomous vehicles with hls4ml}",
    eprint = "2205.07690",
    archivePrefix = "arXiv",
    primaryClass = "cs.CV",
    reportNumber = "FERMILAB-PUB-22-435-PPD",
    doi = "10.1088/2632-2153/ac9cb5",
    journal ="Mach. Learn. Sci. Tech.",
    year = "2022"
}
```
Distributed arithmetic:
```bibtex
@misc{Sun:2025,
      title={da4ml: Distributed Arithmetic for Real-time Neural Networks on FPGAs},
      author={Chang Sun and others},
      year={2025},
      eprint={2507.04535},
      archivePrefix={arXiv},
      primaryClass={cs.AR},
      url={https://arxiv.org/abs/2507.04535},
}
```
binary/ternary networks:
```bibtex
@article{Loncar:2020hqp,
    author = "Ngadiuba, Jennifer and others",
    title = "{Compressing deep neural networks on FPGAs to binary and ternary precision with HLS4ML}",
    eprint = "2003.06308",
    archivePrefix = "arXiv",
    primaryClass = "cs.LG",
    reportNumber = "FERMILAB-PUB-20-167-PPD-SCD",
    doi = "10.1088/2632-2153/aba042",
    journal = "Mach. Learn. Sci. Tech.",
    volume = "2",
    pages = "015001",
    year = "2021"
}
```
Spiking Neural Networks (SNNs):
```bibtex
@misc{dillon2026spikingneuralnetworkinference,
      title={Spiking Neural Network inference on FPGAs with hls4ml},
      author={Barry M. Dillon},
      year={2026},
      eprint={2606.10008},
      archivePrefix={arXiv},
      primaryClass={cs.NE},
      url={https://arxiv.org/abs/2606.10008},
}
```

# Acknowledgments
If you benefited from participating in our community, we ask that you please acknowledge the Fast Machine Learning collaboration and particular individuals who helped you in any publications.
Please use the following text for this acknowledgment:
  > We acknowledge the Fast Machine Learning collective as an open community of multi-domain experts and collaborators. This community and \<names of individuals\>, in particular, were important for the development of this project.

# Funding
We gratefully acknowledge previous and current support from the U.S. National Science Foundation (NSF) Harnessing the Data Revolution (HDR) Institute for <a href="https://a3d3.ai">Accelerating AI Algorithms for Data Driven Discovery (A3D3)</a> under Cooperative Agreement No. <a href="https://www.nsf.gov/awardsearch/showAward?AWD_ID=2117997">PHY-2117997</a>, U.S. Department of Energy (DOE) Office of Science, Office of Advanced Scientific Computing Research under the Real‐time Data Reduction Codesign at the Extreme Edge for Science (XDR) Project (<a href="https://science.osti.gov/-/media/grants/pdf/foas/2021/SC_FOA_0002501.pdf">DE-FOA-0002501</a>), DOE Office of Science, Office of High Energy Physics Early Career Research Program (<a href="https://pamspublic.science.energy.gov/WebPAMSExternal/Interface/Common/ViewPublicAbstract.aspx?rv=df0ae4ab-a46e-481a-9acc-3856b6b041e5&rtc=24&PRoleId=10">DE-SC0021187</a>, DE-0000247070), the European Research Council (ERC) under the European Union's Horizon 2020 research and innovation program (Grant No. <a href="https://doi.org/10.3030/772369">772369</a> and <a href="https://doi.org/10.3030/966696">966696</a>), and the Eric & Wendy Schmidt Fund for Strategic Innovation through the CERN Next Generation Triggers project under grant agreement number SIF-2023-004.

<p align="center">
<img src="https://github.com/fastmachinelearning/hls4ml/assets/29201053/bd1217d4-9930-47b7-8917-ad3fc430c75d" alt="A3D3" width="130"/>
<img src="https://github.com/fastmachinelearning/hls4ml/assets/4932543/16e77374-9829-40a8-800e-8d12018a7cb3" alt="NSF" width="130"/>
<img src="https://github.com/fastmachinelearning/hls4ml/assets/4932543/de6ca6ea-4d1c-4c56-9d93-f759914bbbf9" alt="DOE" width="130"/>
<img src="https://github.com/fastmachinelearning/hls4ml/assets/4932543/7a369971-a381-4bb8-932a-7162b173cbac" alt="ERC" width="130"/>
<img src="https://github.com/user-attachments/assets/7d8cd75d-e0a8-451e-b52c-6f31fa1b8114" alt="NGT" width="130" />
</p>
