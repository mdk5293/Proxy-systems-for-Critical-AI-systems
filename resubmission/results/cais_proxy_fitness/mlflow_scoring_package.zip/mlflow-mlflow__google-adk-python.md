# CAIS Proxy-Fitness Evidence Packet

- Anchor: `mlflow-mlflow`
- Candidate: `google/adk-python`
- Repository URL: https://github.com/google/adk-python

## Repository metadata

Description: An open-source, code-first Python toolkit for building, evaluating, and deploying sophisticated AI agents with flexibility and control.

Topics: agent, agents, agents-sdk, ai, ai-agents, multi-agent-systems, multi-agents, multi-agents-collaboration, aiagentframework, genai, genai-chatbot, llms, agentic, agentic-ai, llm, multi-agent

## Frozen rubric

### MLF01 — Experiment and run tracking

Critical: True

Records model-development runs, parameters, metrics, outputs, or equivalent experimental evidence.

Score: 

Evidence source: 

Evidence note: 

### MLF02 — Model lineage and version management

Critical: True

Supports model versioning, lineage, provenance, registration, or controlled lifecycle transitions.

Score: 

Evidence source: 

Evidence note: 

### MLF03 — Artifact and dependency reproducibility

Critical: False

Captures model artifacts, dependencies, environment information, or packaging needed to reproduce execution.

Score: 

Evidence source: 

Evidence note: 

### MLF04 — Deployment and serving

Critical: False

Supports deployment of models to an inference endpoint or comparable execution environment.

Score: 

Evidence source: 

Evidence note: 

### MLF05 — Validation or promotion workflow

Critical: False

Supports validation state, approval, promotion, aliasing, staging, or comparable model-governance workflow.

Score: 

Evidence source: 

Evidence note: 

### MLF06 — Metadata and artifact retrieval

Critical: False

Provides structured retrieval of runs, models, metadata, artifacts, or associated evidence.

Score: 

Evidence source: 

Evidence note: 

## Retrieved README

# Agent Development Kit (ADK) 2.0

[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)
[![PyPI version](https://img.shields.io/pypi/v/google-adk.svg)](https://pypi.org/project/google-adk/)
[![Python versions](https://img.shields.io/pypi/pyversions/google-adk.svg)](https://pypi.org/project/google-adk/)
[![PyPI downloads](https://static.pepy.tech/badge/google-adk/month)](https://pepy.tech/project/google-adk)
[![Continuous Integration](https://github.com/google/adk-python/actions/workflows/continuous-integration.yml/badge.svg)](https://github.com/google/adk-python/actions/workflows/continuous-integration.yml)
[![Docs](https://img.shields.io/badge/docs-latest-blue.svg)](https://google.github.io/adk-docs/)
[![r/agentdevelopmentkit](https://img.shields.io/badge/Reddit-r%2Fagentdevelopmentkit-FF4500?style=flat&logo=reddit&logoColor=white)](https://www.reddit.com/r/agentdevelopmentkit/)
<a href="https://codewiki.google/github.com/google/adk-python"><img src="https://www.gstatic.com/_/boq-sdlc-agents-ui/_/r/Mvosg4klCA4.svg" alt="Ask Code Wiki" height="20"></a>

<h2 align="center">
  <img src="https://raw.githubusercontent.com/google/adk-python/main/assets/agent-development-kit.png" width="256"/>
</h2>
<h3 align="center">
  An open-source, code-first Python framework for building, evaluating, and deploying sophisticated AI agents with flexibility and control.
</h3>
<h3 align="center">
  Important Links:
  <a href="https://google.github.io/adk-docs/">Docs</a>,
  <a href="https://github.com/google/adk-samples">Samples</a> &
  <a href="https://github.com/google/adk-web">ADK Web</a>.
</h3>
<h3 align="center">
  ADK in other languages:
  <a href="https://github.com/google/adk-java">ADK Java</a>,
  <a href="https://github.com/google/adk-kotlin">ADK Kotlin</a>,
  <a href="https://github.com/google/adk-go">ADK Go</a> &
  <a href="https://github.com/google/adk-js">ADK Typescript</a>.
</h3>

Agent Development Kit (ADK) is a flexible and modular framework that applies
software development principles to AI agent creation. It is designed to
simplify building, deploying, and orchestrating agent workflows, from simple
tasks to complex systems. While optimized for Gemini, ADK is model-agnostic,
deployment-agnostic, and compatible with other frameworks.

## ✨ Key Features

- **Workflow Runtime**: A graph-based execution engine for composing
  deterministic execution flows for agentic apps, with support for routing,
  fan-out/fan-in, loops, retry, state management, dynamic nodes,
  human-in-the-loop, and nested workflows.

- **Task API**: Structured agent-to-agent delegation with multi-turn task
  mode, single-turn controlled output, mixed delegation patterns,
  human-in-the-loop, and task agents as workflow nodes.

- **Modular Multi-Agent Systems**: Design scalable applications by composing
  multiple specialized agents into flexible hierarchies.

- **Rich Tool Ecosystem**: Utilize pre-built tools, custom functions,
  OpenAPI specs, MCP tools or integrate existing tools to give agents diverse
  capabilities, all for tight integration with the Google ecosystem.

- **Code-First Development**: Define agent logic, tools, and orchestration
  directly in Python for ultimate flexibility, testability, and versioning.

- **Agent Config**: Build agents without code. Check out the
  [Agent Config](https://google.github.io/adk-docs/agents/config/) feature.

- **Tool Confirmation**: A [tool confirmation flow (HITL)](https://google.github.io/adk-docs/tools/confirmation/) that can guard tool execution with explicit confirmation and custom input.

- **Deploy Anywhere**: Easily containerize and deploy agents on Cloud Run or
  scale seamlessly with Vertex AI Agent Engine.

## 🚀 Installation

### Stable Release (Recommended)

You can install the latest stable version of ADK using `pip`:

```bash
pip install google-adk
```

**Requirements:** Python 3.10+.

For transitive dependency protection, we recommend to install with our companion
constraints files (for python 3.10 to 3.14).

Choose the constraints file matching your Python version:

```bash
# For example, for Python 3.10
curl -o constraints-3.10.txt https://raw.githubusercontent.com/google/adk-python/main/constraints-3.10.txt
pip install google-adk -c constraints-3.10.txt
rm constraints-3.10.txt
```

To install optional integrations, you can use the following command:

```bash
pip install "google-adk[extensions]"
```

The release cadence is roughly bi-weekly.

### Development Version

Bug fixes and new features are merged into the main branch on GitHub first. If you need access to changes that haven't been included in an official PyPI release yet, you can install directly from the main branch:

```bash
pip install git+https://github.com/google/adk-python.git@main
```

Note: The development version is built directly from the latest code commits. While it includes the newest fixes and features, it may also contain experimental changes or bugs not present in the stable release. Use it primarily for testing upcoming changes or accessing critical fixes before they are officially released.

## Quick Start

> **Beginner Note:** ADK applications are built using two main classes:
> **`Agent`** (defines an AI's instructions, tools, and behavior) and
> **`Workflow`** (orchestrates agents and tasks in a graph-based flow).

### Agent

```python
from google.adk import Agent

root_agent = Agent(
    name="greeting_agent",
    model="gemini-2.5-flash",
    instruction="You are a helpful assistant. Greet the user warmly.",
)
```

### Workflow

```python
from google.adk import Agent, Workflow

generate_fruit_agent = Agent(
    name="generate_fruit_agent",
    instruction="Return the name of a random fruit. Return only the name.",
)

generate_benefit_agent = Agent(
    name="generate_benefit_agent",
    instruction="Tell me a health benefit about the specified fruit.",
)

root_agent = Workflow(
    name="root_agent",
    edges=[("START", generate_fruit_agent, generate_benefit_agent)],
)
```

### Run Locally

```bash
# Interactive CLI
adk run path/to/my_agent

# Web UI (supports multi-agent directories or pointing directly to a single agent folder)
adk web path/to/agents_dir
```

### Development UI

A built-in development UI to help you test, evaluate, debug, and showcase your agent(s).

[![ADK Web UI](https://raw.githubusercontent.com/google/adk-python/main/assets/adk-web-dev-ui.png)](https://youtu.be/TEjqk0eeNy8)

[![Watch on YouTube](https://img.shields.io/badge/YouTube-Watch%20ADK%20Web%20Demo-FF0000?style=flat&logo=youtube&logoColor=white)](https://youtu.be/TEjqk0eeNy8)

### Evaluate Agents

Run the bundled evaluation sample from the repo root:

```bash
adk eval \
    contributing/samples/evaluation/home_automation_agent \
    contributing/samples/evaluation/basic_criteria/home_automation.evalset.json \
    --config_file_path contributing/samples/evaluation/basic_criteria/eval_config.json
```

### 🚀 Deployment Options

Deploying the Agent Locally with Docker Container:

```bash
adk deploy docker --with_ui <agent-folder>
```

Deploying the Agent in Google Cloud (Cloud Run)

```bash
adk deploy cloud_run --with_ui <agent-folder>
```

You may set the following environment variables in adk command, or in a .env file instead.

```bash
adk deploy cloud_run --with_ui --env GOOGLE_GENAI_USE_ENTERPRISE=1 <agent-folder>
```

## 📚 Documentation

- **Getting Started**: https://google.github.io/adk-docs/
- **Guides**: See
  [`docs/guides/`](https://github.com/google/adk-python/tree/main/docs/guides)
  for task-oriented walkthroughs of agents, tools, events, plugins, and
  workflows.
- **Samples**: See
  [`contributing/samples/`](https://github.com/google/adk-python/tree/main/contributing/samples)
  for runnable example agents.

## 🤝 Contributing

We welcome contributions from the community! Whether it's bug reports, feature requests, documentation improvements, or code contributions, please see our:

- [General contribution guideline and flow](https://google.github.io/adk-docs/contributing-guide/).
- [Code Contributing Guidelines](./CONTRIBUTING.md) to get started.

## Community Repo

We have the [adk-python-community repo](https://github.com/google/adk-python-community) that is home to a growing ecosystem of community-contributed tools, third-party
service integrations, and deployment scripts that extend the core capabilities
of the ADK.

## Vibe Coding

If you want to develop an agent via vibe coding the [llms.txt](./llms.txt) and the [llms-full.txt](./llms-full.txt) can be used as context to an LLM. While the former one is a summarized one and the latter one has the full information in case your LLM has a big enough context window.

## Community Events

- [Completed] ADK's 1st community meeting on Wednesday, October 15, 2025. Remember to [join our group](https://groups.google.com/g/adk-community) to get access to the [recording](https://drive.google.com/file/d/1rpXDq5NSH8-MyMeYI6_5pZ3Lhn0X9BQf/view), and [deck](https://docs.google.com/presentation/d/1_b8LG4xaiadbUUDzyNiapSFyxanc9ZgFdw7JQ6zmZ9Q/edit?slide=id.g384e60cdaca_0_658&resourcekey=0-tjFFv0VBQhpXBPCkZr0NOg#slide=id.g384e60cdaca_0_658).

## 📄 License

This project is licensed under the Apache 2.0 License — see the
[LICENSE](LICENSE) file for details.

______________________________________________________________________

*Happy Agent Building!*
